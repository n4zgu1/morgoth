from upload import upload

upload('127.0.0.1', 9999, 'Archiv.zip')